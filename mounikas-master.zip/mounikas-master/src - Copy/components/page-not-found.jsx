import React, { Component } from "react";
class PageNotFound extends Component {
  state = {};
  render() {
    return (
      <div>
        <h4 className="text-center"> 555-pageNotFound</h4>
      </div>
    );
  }
}

export default PageNotFound;

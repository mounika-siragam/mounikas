import React, { Component } from "react";
class Home extends Component {
  state = {};
  render() {
    return (
      <div>
        <h1 className="text-center">homepage</h1>
      </div>
    );
  }
}

export default Home;
